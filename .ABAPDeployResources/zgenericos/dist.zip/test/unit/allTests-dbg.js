sap.ui.define([
	"dma/zgenericos/test/unit/controller/View1.controller"
], function () {
	"use strict";
});